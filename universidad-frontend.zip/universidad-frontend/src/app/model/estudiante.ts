import { Programa } from './programa';
import { Persona } from './persona';

export class Estudiante {

    codigo: number;
    programa: Programa;
    persona: Persona;
    estado: number;

}