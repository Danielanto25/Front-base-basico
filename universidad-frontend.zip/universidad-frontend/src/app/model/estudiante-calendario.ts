import { Estudiante } from './estudiante';
import { Calendario } from './calendario';

export class EstudianteCalendario {

    codigo: number;
    calendario: Calendario;
    estudiante: Estudiante;
    estado: number;

}
