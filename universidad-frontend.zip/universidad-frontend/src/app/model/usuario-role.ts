import { Usuario } from './usuario';
import { Role } from './role';

export class UsuarioRole {

    codigo: number;
    user: Usuario;
    role: Role;
    estado: number;
    
}
