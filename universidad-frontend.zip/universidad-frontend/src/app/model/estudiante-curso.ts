import { Curso } from './curso';
import { EstudianteCalendario } from './estudiante-calendario';

export class EstudianteCurso {

    codigo: number;
    estudianteCalendario: EstudianteCalendario;
    curso: Curso;
    definitiva: number;
    estado: number;
    
}
