import{ Persona } from './persona';

export class Usuario {

    codigo: number;
    usuario: string; 
    clave: string;
    persona: Persona;
    estado: number;

}
