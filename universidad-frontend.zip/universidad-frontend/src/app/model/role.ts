export class Role {

    codigo: number;
    nombre: string;
    estado: number;
    
}
