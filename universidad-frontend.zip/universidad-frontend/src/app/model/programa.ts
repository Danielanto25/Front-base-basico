export class Programa {

    codigo: number;
    nombre: string;
    estado: number;

}
