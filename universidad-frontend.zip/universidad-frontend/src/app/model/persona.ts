export class Persona {

    codigo: number;
    nombre: string;
    apellido: string;
    identificacion: string;
    estado: number;

}
