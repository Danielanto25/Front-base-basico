export class Curso {

    codigo: number;
    nombre: string;
    estado: number;

}
