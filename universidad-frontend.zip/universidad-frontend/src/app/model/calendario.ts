export class Calendario {

    codigo:number;
    nombre:string;
    estado:number;
    
}
