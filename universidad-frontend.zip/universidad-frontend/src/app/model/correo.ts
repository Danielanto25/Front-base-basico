export class Correo{
    descripcion:string;
    asunto:string;
}