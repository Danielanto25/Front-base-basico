import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import {Correo} from '../model/correo';;

@Injectable({
  providedIn: 'root'
})
export class SubirArchivoService {

  private url: string = `${environment.apiUrl}/subir-archivo`;
  constructor(
    private http: HttpClient
  ) { }

  subirArchivoi(archivo:File,json:Correo):Observable<null>{
    let formData:FormData=new FormData();
    formData.set('archivo',archivo);
    formData.set('json',JSON.stringify(json));
    return this.http.post<null>(`${this.url}/subir`,formData);
  }
}
