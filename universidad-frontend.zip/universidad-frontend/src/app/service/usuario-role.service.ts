import { Injectable } from '@angular/core';
import { UsuarioRole } from '../model/usuario-role';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsuarioRoleService {

  private url: string = `${environment.apiUrl}/usuario-role`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<UsuarioRole[]> {
    return this.http.get<UsuarioRole[]>(`${this.url}/listar`);
  }

  crear(usuarioRole: UsuarioRole): Observable<void> {
    return this.http.post<void>(`${this.url}/insertar`, usuarioRole);
  }

  editar(usuarioRole: UsuarioRole): Observable<void> {
    return this.http.put<void>(`${this.url}/update`, usuarioRole)
  }

  eliminar(usuarioRole: UsuarioRole): Observable<void> {
    return this.http.put<void>(`${this.url}/delete`, usuarioRole);
  }

}
