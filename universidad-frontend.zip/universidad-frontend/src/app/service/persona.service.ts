import { Injectable } from '@angular/core';
import { Persona } from '../model/persona';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class PersonaService {

  private url: string = `${environment.apiUrl}/persona`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<Persona[]> {
    return this.http.get<Persona[]>(`${this.url}/select`);
  }

  crear(persona: Persona): Observable<void> {
    return this.http.post<void>(`${this.url}/insert`, persona);
  }

  editar(persona: Persona): Observable<void> {
    return this.http.put<void>(`${this.url}/update`, persona)
  }

  eliminar(persona: Persona): Observable<void> {
    return this.http.put<void>(`${this.url}/delete`, persona);
  }

}
