import { Injectable } from '@angular/core';
import { Role } from '../model/role';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class RoleService {

  private url: string = `${environment.apiUrl}/role`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<Role[]> {
    return this.http.get<Role[]>(`${this.url}/listar`);
  }

  crear(role: Role): Observable<void> {
    return this.http.post<void>(`${this.url}/insert`, role);
  }

  editar(role: Role): Observable<void> {
    return this.http.put<void>(`${this.url}/update`, role)
  }

  eliminar(role: Role): Observable<void> {
    return this.http.put<void>(`${this.url}/delete`, role);
  }
}
