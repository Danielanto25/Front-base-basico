import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import {Correo} from '../model/correo';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CorreoService {

  private url: string = `${environment.apiUrl}/correo`;

  constructor(
    private http:HttpClient
  ) { }

  enviarCorreo(archivo:File,json:Correo,imagen:File):Observable<void>{
    let formData:FormData=new FormData();
    formData.set('archivo',archivo);
    formData.set('imagen',imagen);
    formData.set('json',JSON.stringify(json));
    return this.http.post<null>(`${this.url}/correo`,formData);
  }
  enviarCorreoSinImagen(archivo:File,json:Correo):Observable<void>{
    let formData:FormData=new FormData();
    formData.set('archivo',archivo);
    formData.set('json',JSON.stringify(json));
    return this.http.post<null>(`${this.url}/correo-sin-imagen`,formData);
  }
  enviarCorreoSinArchivo(imagen:File,json:Correo):Observable<void>{
    let formData:FormData=new FormData();
    formData.set('imagen',imagen);
    formData.set('json',JSON.stringify(json));
    return this.http.post<null>(`${this.url}/correo-sin-archivo`,formData);
  }
  enviarCorreoSoloTexto(json:Correo):Observable<void>{
    let formData:FormData=new FormData();
    formData.set('json',JSON.stringify(json));
    return this.http.post<null>(`${this.url}/correo-solo-texto`,formData);
  }



}
