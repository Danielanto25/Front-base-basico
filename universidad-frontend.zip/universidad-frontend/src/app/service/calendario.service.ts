import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { Calendario } from '../model/calendario';

@Injectable({
  providedIn: 'root'
})
export class CalendarioService {

  private url: string = `${environment.apiUrl}/calendario`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<Calendario[]> {
    return this.http.get<Calendario[]>(`${this.url}/listar`);
  }

  crear(calendario: Calendario): Observable<void> {
    return this.http.post<void>(`${this.url}/insert`, calendario);
  }

  editar(calendario: Calendario): Observable<void> {
    return this.http.put<void>(`${this.url}/update`, calendario);
  }

  eliminar(calendario: Calendario): Observable<void> {
    return this.http.put<void>(`${this.url}/delete`, calendario);
  }
}
