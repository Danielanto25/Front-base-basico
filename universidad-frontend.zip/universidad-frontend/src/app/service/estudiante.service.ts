import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment';
import { Observable } from 'rxjs';
import { Estudiante } from '../model/estudiante';

@Injectable({
  providedIn: 'root'
})
export class EstudianteService {
  private url: string = `${environment.apiUrl}/estudiante`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<Estudiante[]> {
    return this.http.get<Estudiante[]>(`${this.url}/listar`);
  }

  crear(estudiante: Estudiante): Observable<void> {
    return this.http.post<void>(`${this.url}/insert`, estudiante);
  }

  editar(estudiante: Estudiante): Observable<void> {
    return this.http.put<void>(`${this.url}/update`, estudiante)
  }

  eliminar(estudiante: Estudiante): Observable<void> {
    return this.http.put<void>(`${this.url}/delete`, estudiante);
  }

  listarcodigo():Observable<Estudiante>{
    return this.http.get<Estudiante>(`${this.url}/listar-codigo`);
  }
}
