import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { Curso } from '../model/curso';

@Injectable({
  providedIn: 'root'
})
export class CursoService {

  private url: string = `${environment.apiUrl}/curso`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<Curso[]> {
    return this.http.get<Curso[]>(`${this.url}/listar`);
  }

  crear(curso: Curso): Observable<void> {
    return this.http.post<void>(`${this.url}/insert`, curso);
  }

  editar(curso: Curso): Observable<void> {
    return this.http.put<void>(`${this.url}/update`, curso)
  }

  eliminar(curso: Curso): Observable<void> {
    return this.http.put<void>(`${this.url}/delete`, curso);
  }

}
