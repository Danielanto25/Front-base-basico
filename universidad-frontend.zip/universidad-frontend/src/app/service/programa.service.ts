import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Programa } from '../model/programa';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../environments/environment';

@Injectable({
  providedIn: 'root'
})
export class ProgramaService {

  private url: string = `${environment.apiUrl}/programa`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<Programa[]> {
    return this.http.get<Programa[]>(`${this.url}/listar`);
  }

  crear(programa: Programa): Observable<any> {
    return this.http.post<any>(`${this.url}/insert`, programa);
  }

  editar(programa: Programa): Observable<any> {
    return this.http.put<any>(`${this.url}/update`, programa)
  }

  eliminar(programa: Programa): Observable<any> {
    return this.http.put<any>(`${this.url}/deñete`, programa);
  }
  
}
