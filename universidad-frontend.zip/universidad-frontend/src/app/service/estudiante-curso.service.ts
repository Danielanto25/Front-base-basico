import { Injectable } from '@angular/core';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { EstudianteCurso } from '../model/estudiante-curso';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EstudianteCursoService {

  private url: string = `${environment.apiUrl}/estudiante-curso`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(codigo: number): Observable<EstudianteCurso[]> {
    return this.http.get<EstudianteCurso[]>(`${this.url}/select/${codigo}`);
  }

  crear(estudianteCurso: EstudianteCurso): Observable<any> {
    return this.http.post<any>(`${this.url}/insert`, estudianteCurso);
  }

  editar(estudianteCurso: EstudianteCurso): Observable<any> {
    return this.http.put<any>(`${this.url}/update`, estudianteCurso)
  }

  eliminar(estudianteCurso: EstudianteCurso): Observable<any> {
    return this.http.put<any>(`${this.url}/delete`, estudianteCurso);
  }

  notasPdf(estudiante: number): Observable<any> {
    return this.http.get(`${this.url}/generar-pdf/${estudiante}`, {responseType: `blob`});
  }

  cursosPdf(codigo:number):Observable<any>{

    return this.http.get(`${this.url}/cursos-pdf/${codigo}`,{responseType:'blob'});

  }
  listar(codigo:number):Observable<EstudianteCurso[]>{
    return this.http.get<EstudianteCurso[]>(`${this.url}/listar-cursos-estudiante/${codigo}`)
  }

}
