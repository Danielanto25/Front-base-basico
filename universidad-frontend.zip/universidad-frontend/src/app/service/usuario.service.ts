import { Injectable } from '@angular/core';
import { Usuario } from '../model/usuario';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UsuarioService {

  private url: string = `${environment.apiUrl}/usuario`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<Usuario[]> {
    return this.http.get<Usuario[]>(`${this.url}/listar`);
  }

  crear(usuario: Usuario): Observable<void> {
    return this.http.post<void>(`${this.url}/insert`, usuario);
  }

  editar(usuario: Usuario): Observable<void> {
    return this.http.put<void>(`${this.url}/update`, usuario)
  }

  eliminar(usuario: Usuario): Observable<void> {
    return this.http.put<void>(`${this.url}/delete`, usuario);
  }

  listarRole(usuario: String): Observable<String[]>{
    return this.http.get<String[]>(`${this.url}/listar-role/${usuario}`);
  }

}
