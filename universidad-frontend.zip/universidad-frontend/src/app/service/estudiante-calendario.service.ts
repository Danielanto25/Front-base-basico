import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { EstudianteCalendario } from '../model/estudiante-calendario';

@Injectable({
  providedIn: 'root'
})
export class EstudianteCalendarioService {

  private url: string = `${environment.apiUrl}/estudiante-calendario`;

  constructor(
    private http: HttpClient
  ) { }

  buscarTodo(): Observable<EstudianteCalendario[]> {
    return this.http.get<EstudianteCalendario[]>(`${this.url}/listar`);
  }

  crear(estudianteCalendario: EstudianteCalendario): Observable<void> {
    return this.http.post<void>(`${this.url}/insert`, estudianteCalendario);
  }

  editar(estudianteCalendario: EstudianteCalendario): Observable<void> {
    return this.http.put<void>(`${this.url}/update`, estudianteCalendario);
  }

  eliminar(estudianteCalendario: EstudianteCalendario): Observable<void> {
    return this.http.put<void>(`${this.url}/delete`, estudianteCalendario);
  }
}
