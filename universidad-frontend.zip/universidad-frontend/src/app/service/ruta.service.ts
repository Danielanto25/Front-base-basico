import { Injectable, Output, EventEmitter } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class RutaService {

  @Output()
  titulo:EventEmitter<string>=new EventEmitter;
  constructor() { }
}
