import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { LogicaGuardService } from './logica-guard.service';
import { role } from '../shared/role';

@Injectable({
  providedIn: 'root'
})
export class EstudianteGuardService implements CanActivate{

  constructor(
    private logicaGuard:LogicaGuardService,

  ) { }
  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean  {

    return this.logicaGuard.permisosValidos([role.estudiante]);
  }
}
