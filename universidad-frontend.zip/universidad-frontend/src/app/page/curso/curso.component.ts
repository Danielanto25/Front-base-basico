import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { Curso } from '../../model/curso'
import { MatPaginator } from '@angular/material/paginator';
import { CursoService } from 'src/app/service/curso.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-curso',
  templateUrl: './curso.component.html',
  styleUrls: ['./curso.component.css']
})
export class CursoComponent implements OnInit {

  form: FormGroup;
  editar: boolean = false;

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'nombre','estado', 'editar'];

  dataSource = new MatTableDataSource<Curso>([]);

  mensajeSatisfactorio: string = 'Satisfactorio';

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private fb: FormBuilder,
    private cursoService: CursoService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService
  ) {

  }

  ngOnInit(): void {
    this.buscarPersona();
    this.initForm();
  }

  private initForm(): void {
    this.form = this.fb.group({
      nombre: new FormControl('', Validators.required),
      codigo: new FormControl(''),
      estado: new FormControl('', Validators.required)
    })
  }

  clickEnviar() {

    let curso: Curso = new Curso();
    this.spinner.show();
    curso.codigo = this.form.get('codigo').value;
    curso.nombre = this.form.get('nombre').value;
    curso.estado = this.form.get('estado').value;

    if (!this.editar) {

      this.registrar(curso);

    } else {

      this.actualizar(curso);

    }

  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    this.spinner.show();
    this.cursoService.eliminar(this.form.get('codigo').value).subscribe(data => {
      this.spinner.hide();


        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();
        this.editar = false;
        this.buscarPersona();

    }, err => this.mensajeError(err));

  }

  registrar(curso: Curso): void {

    this.cursoService.crear(curso).subscribe(data => {

      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscarPersona();

    }, err => this.mensajeError(err));
  }

  actualizar(curso: Curso): void {

    this.cursoService.editar(curso).subscribe(data => {
      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscarPersona();

    }, err => this.mensajeError(err));

  }

  buscarPersona() {
    this.cursoService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<Curso>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: Curso) {
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('nombre').setValue(element.nombre);
    this.form.get('estado').setValue(element.estado);
  }
}

interface Estado {
  value: number;
  viewValue: string;
}
