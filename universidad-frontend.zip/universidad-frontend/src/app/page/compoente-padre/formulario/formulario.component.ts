import { Component, OnInit, Input } from '@angular/core';
import { Persona } from 'src/app/model/persona';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent implements OnInit {

  @Input('persona')
  persona: Persona;
 


  constructor() { }

  ngOnInit(): void {
  }

  @Input('persona2')
  set persona2(persona:Persona){
    if(persona==null){
      return;
    }
    console.log(persona.apellido);
  }

}
