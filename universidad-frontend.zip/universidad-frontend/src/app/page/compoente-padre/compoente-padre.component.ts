import { Component, OnInit } from '@angular/core';
import { Persona } from 'src/app/model/persona';

@Component({
  selector: 'app-compoente-padre',
  templateUrl: './compoente-padre.component.html',
  styleUrls: ['./compoente-padre.component.css']
})
export class CompoentePadreComponent implements OnInit {

  persona:Persona;

  constructor() { }

  ngOnInit(): void {
    console.log("componente padre funcionando")
  }

  personaSeleccionada(persona:Persona):void{
    this.persona=persona;
    console.log(persona);
  }
}
