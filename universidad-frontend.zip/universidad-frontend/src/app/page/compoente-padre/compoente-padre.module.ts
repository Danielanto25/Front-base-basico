import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CompoentePadreRoutingModule } from './compoente-padre-routing.module';
import { CompoentePadreComponent } from './compoente-padre.component';
import { TablaComponent } from './tabla/tabla.component';
import { FormularioComponent } from './formulario/formulario.component';


@NgModule({
  declarations: [CompoentePadreComponent, TablaComponent, FormularioComponent],
  imports: [
    CommonModule,
    CompoentePadreRoutingModule
  ]
})
export class CompoentePadreModule { }
