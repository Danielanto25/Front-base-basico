import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { PersonaService } from 'src/app/service/persona.service';
import { Persona } from 'src/app/model/persona';

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})
export class TablaComponent implements OnInit {

  persona: Persona[];

  @Output('personaSeleccionada')
  personaSeleccionada:EventEmitter<Persona>=new EventEmitter();

  constructor(
    private personaService: PersonaService,
  ) { }

  ngOnInit(): void {
    this.buscarPersona()
  }



  private buscarPersona(): void {
    this.personaService.buscarTodo().subscribe(data => {
      this.persona = data;
    });
  }

  click(persona:Persona):void{
    this.personaSeleccionada.emit(persona);
  }
}
