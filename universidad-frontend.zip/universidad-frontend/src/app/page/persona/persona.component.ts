import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { Persona } from '../../model/persona';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { PersonaService } from '../../service/persona.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-persona',
  templateUrl: './persona.component.html',
  styleUrls: ['./persona.component.css']
})
export class PersonaComponent implements OnInit {

  form: FormGroup;
  editar: boolean = false;

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'nombre', 'apellido', 'identificacion','estado', 'editar'];

  dataSource = new MatTableDataSource<Persona>([]);

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private fb: FormBuilder,
    private personaService: PersonaService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService
  ) {

  }

  ngOnInit(): void {
    this.buscarPersona();
    this.initForm();
  }

  private initForm(): void {
    this.form = this.fb.group({
      nombre: new FormControl('', Validators.required),
      apellido: new FormControl('', Validators.required),
      identificacion: new FormControl('', Validators.required),
      codigo: new FormControl(''),
      estado: new FormControl('', Validators.required)
    })
  }

  clickEnviar() {

    let persona: Persona = new Persona();
    this.spinner.show();
    persona.apellido = this.form.get('apellido').value;
    persona.nombre = this.form.get('nombre').value;
    persona.identificacion = this.form.get('identificacion').value;
    persona.codigo = this.form.get('codigo').value;
    persona.estado = this.form.get('estado').value;

    if (!this.editar) {

      this.registrar(persona);

    } else {

      this.actualizar(persona);

    }

  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    let persona: Persona = new Persona();
    this.spinner.show();
    persona.apellido = this.form.get('apellido').value;
    persona.nombre = this.form.get('nombre').value;
    persona.identificacion = this.form.get('identificacion').value;
    persona.codigo = this.form.get('codigo').value;
    persona.estado = this.form.get('estado').value;

    this.spinner.show();
    this.personaService.eliminar(persona).subscribe(data => {
      this.spinner.hide();
        this.toastr.success('satisfactorio');
        this.form.reset();
        this.editar = false;
        this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  registrar(persona: Persona): void {

    this.personaService.crear(persona).subscribe(data => {

      this.spinner.hide();
      this.form.reset();
      console.log(data);

  this.toastr.success('Satisfactorio');
        this.buscarPersona();

    }, err => this.mensajeError(err));
  }

  actualizar(persona: Persona): void {

    this.personaService.editar(persona).subscribe(data => {
      this.spinner.hide();

      this.spinner.hide();
      this.form.reset();

  this.toastr.success('Satisfactorio');
        this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  buscarPersona() {
    this.personaService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<Persona>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: Persona){
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('nombre').setValue(element.nombre);
    this.form.get('apellido').setValue(element.apellido);
    this.form.get('identificacion').setValue(element.identificacion);
    this.form.get('estado').setValue(element.estado);
  }
}
interface Estado {
  value: number;
  viewValue: string;
}
