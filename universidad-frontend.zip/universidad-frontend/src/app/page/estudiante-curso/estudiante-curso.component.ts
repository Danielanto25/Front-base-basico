import { Component, OnInit, ViewChild } from '@angular/core';
import { saveAs } from 'file-saver';
import { EstudianteCursoService } from '../../service/estudiante-curso.service';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { EstudianteCurso } from 'src/app/model/estudiante-curso';
import { EstudianteCalendario } from 'src/app/model/estudiante-calendario';
import { Curso } from 'src/app/model/curso';
import { EstudianteService } from 'src/app/service/estudiante.service';
import { CursoService } from 'src/app/service/curso.service';
import { EstudianteCalendarioService } from 'src/app/service/estudiante-calendario.service';


@Component({
  selector: 'app-estudiante-curso',
  templateUrl: './estudiante-curso.component.html',
  styleUrls: ['./estudiante-curso.component.css']
})
export class EstudianteCursoComponent implements OnInit {

  codigo: number;

  form: FormGroup;
  editar: boolean = false;
  lstEscCodigo: EstudianteCalendario[];
  lstCurCodigo: Curso[];

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'estudianteCalendario', 'definitiva', 'curso', 'estado', 'editar'];

  dataSource = new MatTableDataSource<EstudianteCurso>([]);

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private estudianteCursoService: EstudianteCursoService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private fb: FormBuilder,
    private estudianteService: EstudianteService,
    private escCalendarioService: EstudianteCalendarioService,
    private cursoService: CursoService
  ) { }

  ngOnInit(): void {
    this.obtenerCodigoEstudiante();
    this.listarEstudianteCalendario();
    this.listarCurso();
    this.initForm();
  }

  obtenerCodigoEstudiante(): void {

    this.estudianteService.listarcodigo().subscribe(data => {


      this.codigo = data.codigo;
      this.buscarPersona();
    }), err => this.mensajeError(err);

  }


  clickImprimir(): void {

    this.estudianteCursoService.cursosPdf(this.codigo).subscribe(data => {

      let documento: File = new File([data], 'cursos-pdf ' + this.codigo + '.pdf', { type: 'aplication/pdf' });

      saveAs(documento);

    }), err => this.mensajeError(err);


    this.buscarPersona();

  }

  generarPdf(): void {

    this.estudianteCursoService.notasPdf(this.codigo).subscribe(data => {

      let notas: File = new File([data], 'notasEstudiante.pdf', {'type':'application-pdf'});
      saveAs(notas);
      this.spinner.hide();
      this.toastr.success(data.respuesta);

    }, err => this.mensajeError(err));

  }

  initForm(): void {
    this.form = this.fb.group({
      estudianteCalendario: new FormControl('', Validators.required),
      curso: new FormControl('', Validators.required),
      definitiva: new FormControl('', Validators.required),
      codigo: new FormControl(''),
      estado: new FormControl('', Validators.required)
    })
  }

  clickEnviar() {

    let estudianteCurso: EstudianteCurso = new EstudianteCurso();
    let estudianteCalendario: EstudianteCalendario = new EstudianteCalendario();
    let curso: Curso = new Curso();

    this.spinner.show();
    estudianteCalendario.codigo = this.form.get('estudianteCalendario').value;
    estudianteCurso.estudianteCalendario = estudianteCalendario;
    curso.codigo = this.form.get('curso').value;
    estudianteCurso.curso = curso;
    estudianteCurso.definitiva = this.form.get('definitiva').value;
    estudianteCurso.codigo = this.form.get('codigo').value;
    estudianteCurso.estado = this.form.get('estado').value;

    if (!this.editar) {

      this.registrar(estudianteCurso);

    } else {

      this.actualizar(estudianteCurso);

    }

    this.editar= false;

  }

  listarEstudianteCalendario() {
    this.escCalendarioService.buscarTodo().subscribe(data => {
      this.lstEscCodigo = data;
    })
  }
  listarCurso() {
    this.cursoService.buscarTodo().subscribe(data => {
      this.lstCurCodigo = data;
    })
  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    let estudianteCurso: EstudianteCurso = new EstudianteCurso();
    let estudianteCalendario: EstudianteCalendario = new EstudianteCalendario();
    let curso: Curso = new Curso();

    this.spinner.show();
    estudianteCalendario.codigo = this.form.get('estudianteCalendario').value;
    estudianteCurso.estudianteCalendario = estudianteCalendario;
    curso.codigo = this.form.get('curso').value;
    estudianteCurso.curso = curso;
    estudianteCurso.definitiva = this.form.get('definitiva').value;
    estudianteCurso.codigo = this.form.get('codigo').value;
    estudianteCurso.estado = this.form.get('estado').value;

    this.spinner.show();
    this.estudianteCursoService.eliminar(estudianteCurso).subscribe(data => {
      this.spinner.hide();
        this.toastr.success('satisfactorio');
        this.form.reset();
        this.editar = false;
        this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  registrar(estudianteCurso: EstudianteCurso): void {

    this.estudianteCursoService.crear(estudianteCurso).subscribe(data => {

      this.spinner.hide();
      this.form.reset();

  this.toastr.success('Satisfactorio');
        this.buscarPersona();

    }, err => this.mensajeError(err));
  }

  actualizar(estudianteCurso: EstudianteCurso): void {

    this.estudianteCursoService.editar(estudianteCurso).subscribe(data => {
      this.spinner.hide();

      this.spinner.hide();
      this.form.reset();

  this.toastr.success('Satisfactorio');
        this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  buscarPersona() {
    this.estudianteCursoService.buscarTodo(this.codigo).subscribe(data => {
      this.dataSource = new MatTableDataSource<EstudianteCurso>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: EstudianteCurso){
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('estudianteCalendario').setValue(element.estudianteCalendario.codigo);
    this.form.get('curso').setValue(element.curso.codigo);
    this.form.get('definitiva').setValue(element.definitiva);
    this.form.get('estado').setValue(element.estado);
  }
}

interface Estado {
  value: number;
  viewValue: string;
}
