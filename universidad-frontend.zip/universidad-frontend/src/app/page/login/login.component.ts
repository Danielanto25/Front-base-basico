import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { LoginService } from 'src/app/service/login.service';
import { environment } from 'src/environments/environment';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private loginService: LoginService,
    private router: Router
  ) { }




  ngOnInit(): void {
    this.initForm();
    this.validar();
  }


  private initForm(): void {
    this.form = this.fb.group({
      usuario: new FormControl('', Validators.required),
      clave: new FormControl('', Validators.required),
    })
  }

  onLoginClick(): void {

    this.loginService.login(this.form.get('usuario').value, this.form.get('clave').value).subscribe(res => {

      sessionStorage.setItem(environment.tokenName, res.access_token);
      // redireccionar a pagina de inciio
      console.log(res);
      localStorage.setItem('usuario',this.form.get('usuario').value);
      this.router.navigateByUrl('home');
    }, err => {

      console.log(err);

      if (err.status == 500) {

        // error en el servidor
        console.log('error');

      } else {

        // credenciales incorrectas
        console.log('credenciales incorrectas');
      }

    });
  }

  validar():void{
    if(sessionStorage.getItem(environment.tokenName)!=null){
      this.router.navigateByUrl('/persona');
    }
  }

}
