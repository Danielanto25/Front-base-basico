import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sin-permiso',
  templateUrl: './sin-permiso.component.html',
  styleUrls: ['./sin-permiso.component.css']
})
export class SinPermisoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
