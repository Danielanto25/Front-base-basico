import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ComponentePadreRoutingModule } from './componente-padre-routing.module';
import { ComponentePadreComponent } from './componente-padre.component';
import { FormularioComponent } from './formulario/formulario.component';
import { TablaComponent } from './tabla/tabla.component';


@NgModule({
  declarations: [ComponentePadreComponent, FormularioComponent, TablaComponent],
  imports: [
    CommonModule,
    ComponentePadreRoutingModule
  ]
})
export class ComponentePadreModule { }
