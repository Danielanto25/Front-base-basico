import { Component, OnInit } from '@angular/core';
import { Role } from 'src/app/model/role';

@Component({
  selector: 'app-componente-padre',
  templateUrl: './componente-padre.component.html',
  styleUrls: ['./componente-padre.component.css']
})
export class ComponentePadreComponent implements OnInit {

  role: Role;

  constructor() { }

  ngOnInit(): void {
  }

  recibirRole(role: Role):void{

    this.role = role;
    console.log(role);

  }

}
