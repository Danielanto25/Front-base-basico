import { Component, OnInit, Input } from '@angular/core';
import { Role } from 'src/app/model/role';

@Component({
  selector: 'app-formulario',
  templateUrl: './formulario.component.html',
  styleUrls: ['./formulario.component.css']
})
export class FormularioComponent implements OnInit {

  @Input('role')
  role: Role;

  constructor() { }

  ngOnInit(): void {
  }

  @Input('role2')
  set role2(role: Role){

    if(role==null){
      return;
    }

    console.log(role);
  }

}
