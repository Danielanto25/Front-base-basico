import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { RoleService } from 'src/app/service/role.service';
import { Role } from 'src/app/model/role';

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})
export class TablaComponent implements OnInit {

  lstRole: Role[];

  @Output('roleSeleccionado')
  roleSeleccionado: EventEmitter<Role>= new EventEmitter();

  constructor(
    private roleService: RoleService
  ) { }

  ngOnInit(): void {
    this.listarRole();
  }

  listarRole(){
    this.roleService.buscarTodo().subscribe(data=>{
      this.lstRole = data;
    }
      
      )
  }

  onRowClick(role: Role): void{

    this.roleSeleccionado.emit(role);

  }

}
