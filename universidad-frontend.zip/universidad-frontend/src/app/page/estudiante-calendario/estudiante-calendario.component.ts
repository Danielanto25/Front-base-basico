import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { EstudianteCalendarioService } from 'src/app/service/estudiante-calendario.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { EstudianteCalendario } from 'src/app/model/estudiante-calendario';
import { Estudiante } from 'src/app/model/estudiante';
import { Calendario } from 'src/app/model/calendario';
import { EstudianteService } from 'src/app/service/estudiante.service';
import { CalendarioService } from 'src/app/service/calendario.service';

@Component({
  selector: 'app-estudiante-calendario',
  templateUrl: './estudiante-calendario.component.html',
  styleUrls: ['./estudiante-calendario.component.css']
})
export class EstudianteCalendarioComponent implements OnInit {

  form: FormGroup;
  editar: boolean = false;
  lstEstCodigo: Estudiante[];
  lstCalCodigo: Calendario[];

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'estudiante', 'calendario', 'estado', 'editar'];

  dataSource = new MatTableDataSource<EstudianteCalendario>([]);

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private fb: FormBuilder,
    private estudianteCalendarioService: EstudianteCalendarioService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private estudianteService: EstudianteService,
    private calendarioService: CalendarioService
  ) {

  }

  ngOnInit(): void {
    this.buscarPersona();
    this.initForm();
    this.listarCalendario();
    this.listarEstudiante();
  }

  private initForm(): void {
    this.form = this.fb.group({
      estudiante: new FormControl('', Validators.required),
      calendario: new FormControl('', Validators.required),
      codigo: new FormControl(''),
      estado: new FormControl('', Validators.required)
    })
  }

  clickEnviar() {

    let estudiante: Estudiante = new Estudiante();
    let calendario: Calendario = new Calendario();
    let estudianteCalendario: EstudianteCalendario = new EstudianteCalendario();
    this.spinner.show();

    estudianteCalendario.codigo = this.form.get('codigo').value;

    estudiante.codigo = this.form.get('estudiante').value;
    calendario.codigo = this.form.get('calendario').value;

    estudianteCalendario.calendario = calendario;
    estudianteCalendario.estudiante = estudiante;

    estudianteCalendario.estado = this.form.get('estado').value;

    if (!this.editar) {

      this.registrar(estudianteCalendario);

    } else {

      this.actualizar(estudianteCalendario);

    }

    this.editar = false;

  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    let estudiante: Estudiante = new Estudiante();
    let calendario: Calendario = new Calendario();
    let estudianteCalendario: EstudianteCalendario = new EstudianteCalendario();
    this.spinner.show();

    estudianteCalendario.codigo = this.form.get('codigo').value;

    estudiante.codigo = this.form.get('estudiante').value;
    calendario.codigo = this.form.get('calendario').value;

    estudianteCalendario.calendario = calendario;
    estudianteCalendario.estudiante = estudiante;

    estudianteCalendario.estado = this.form.get('estado').value;

    this.spinner.show();
    this.estudianteCalendarioService.eliminar(estudianteCalendario).subscribe(data => {
      this.spinner.hide();
      this.toastr.success('Satisfactorio');
      this.form.reset();
      this.editar = false;
      this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  registrar(estudianteCalendario: EstudianteCalendario): void {

    this.estudianteCalendarioService.crear(estudianteCalendario).subscribe(data => {

      this.spinner.hide();
      this.form.reset();

      this.toastr.success('Satisfactorio');
      this.buscarPersona();

    }, err => this.mensajeError(err));
  }

  actualizar(estudianteCalendario: EstudianteCalendario): void {

    this.estudianteCalendarioService.editar(estudianteCalendario).subscribe(data => {
      this.spinner.hide();

      this.spinner.hide();
      this.form.reset();

      this.toastr.success('Satisfactorio');
      this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  buscarPersona() {
    this.estudianteCalendarioService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<EstudianteCalendario>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: EstudianteCalendario) {
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('estudiante').setValue(element.estudiante.codigo);
    this.form.get('calendario').setValue(element.calendario.codigo);
    this.form.get('estado').setValue(element.estado);
  }

  listarCalendario() {
    this.calendarioService.buscarTodo().subscribe(data => {
      this.lstCalCodigo = data;
    })
  }
  listarEstudiante() {
    this.estudianteService.buscarTodo().subscribe(data => {
      this.lstEstCodigo = data;
    })
  }

}

interface Estado {
  value: number;
  viewValue: string;
}