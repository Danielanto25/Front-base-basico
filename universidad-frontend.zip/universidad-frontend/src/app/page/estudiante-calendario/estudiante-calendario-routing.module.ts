import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EstudianteCalendarioComponent } from './estudiante-calendario.component';


const routes: Routes = [
  {
    path: '',
    component: EstudianteCalendarioComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EstudianteCalendarioRoutingModule { }
