import { Component, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Usuario } from '../../model/usuario';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { UsuarioService } from '../../service/usuario.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Persona } from 'src/app/model/persona';
import { PersonaService } from 'src/app/service/persona.service';
import { Role } from 'src/app/model/role';
import { role } from 'src/app/shared/role';

@Component({
  selector: 'app-usuario',
  templateUrl: './usuario.component.html',
  styleUrls: ['./usuario.component.css']
})
export class UsuarioComponent implements OnInit {

  usuario: string;

  form: FormGroup;
  editar: boolean = false;

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'usuario', 'persona', 'estado', 'editar'];

  dataSource = new MatTableDataSource<Usuario>([]);

  mensajeSatisfactorio:string='Satisfactorio';
  
  variable2: number;

  lstPerCodigo: Persona[];

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private fb: FormBuilder,
    private usuarioService: UsuarioService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private personaService: PersonaService
  ) {

  }

  ngOnInit(): void {
    this.buscar();
    this.initForm();
    this.listarPersona();
  }

  private initForm(): void {
    this.form = this.fb.group({
      usuario: new FormControl('', Validators.required),
      clave: new FormControl('', Validators.required),
      persona: new FormControl('', Validators.required),
      estado: new FormControl('', Validators.required),
      codigo: new FormControl('')
    })
  }

  clickEnviar() {

    let usuario: Usuario = new Usuario();
    let persona: Persona = new Persona();
    this.spinner.show();
    usuario.usuario = this.form.get('usuario').value;
    usuario.clave = this.form.get('clave').value;
    persona.codigo = this.form.get('persona').value;
    usuario.persona = persona
    usuario.estado = this.form.get('estado').value;
    usuario.codigo = this.form.get('codigo').value;

    console.log(usuario);

    if (!this.editar) {

      this.registrar(usuario);

    } else {

      this.actualizar(usuario);

    }

  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    let usuario: Usuario = new Usuario();
    let persona: Persona = new Persona();
    this.spinner.show();
    usuario.usuario = this.form.get('usuario').value;
    usuario.clave = this.form.get('clave').value;
    persona.codigo = this.form.get('persona').value;
    usuario.persona = persona
    usuario.estado = this.form.get('estado').value;
    usuario.codigo = this.form.get('codigo').value;

    this.spinner.show();
    this.usuarioService.eliminar(usuario).subscribe(data => {
      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();
        this.editar = false;
        this.buscar();
    }, err => this.mensajeError(err));

  }

  registrar(usuario: Usuario): void {

    this.usuarioService.crear(usuario).subscribe(data => {

      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscar();
        this.editar=false;

    }, err => this.mensajeError(err));
  }

  actualizar(usuario: Usuario): void {

    this.usuarioService.editar(usuario).subscribe(data => {
      this.spinner.hide();


        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.editar=false;

        this.buscar();  
    }, err => this.mensajeError(err));

  }

  buscar() {
    this.usuarioService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<Usuario>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: Usuario){
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('usuario').setValue(element.usuario);
    this.form.get('clave').setValue(element.clave);
    this.form.get('persona').setValue(element.persona.codigo);
    this.form.get('estado').setValue(element.estado);
  }

  listarPersona() {
    this.personaService.buscarTodo().subscribe(data => {
      
      this.lstPerCodigo = data;
      
    })
  }

  onRowClick(element: Usuario){

    this.usuario = element.usuario;

  }
}

interface Estado {
  value: number;
  viewValue: string;
}
