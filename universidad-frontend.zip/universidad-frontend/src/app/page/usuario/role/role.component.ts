import { Component, OnInit, Input } from '@angular/core';
import { UsuarioService } from 'src/app/service/usuario.service';
import { role } from 'src/app/shared/role';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit {

  lstRolePorUsuario: String[];

  constructor(
    private usuarioService: UsuarioService
  ) { }

  ngOnInit(): void {
  }

  @Input('usuarioSeleccionado')
  set usuarioSeleccionado(usuarioSeleccionado: string) {

    if (usuarioSeleccionado == null) {
      return;
    }

    console.log(usuarioSeleccionado);
    this.listarRole(usuarioSeleccionado);
    
  }

  listarRole(usuario: string) {
    this.usuarioService.listarRole(usuario).subscribe(data => {
      this.lstRolePorUsuario = data;
      console.log(data);
    })

  }
}
