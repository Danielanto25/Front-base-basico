import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { CalendarioService } from '../../service/calendario.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { MatTableDataSource } from '@angular/material/table';
import { Calendario } from 'src/app/model/calendario';

@Component({
  selector: 'app-calendario',
  templateUrl: './calendario.component.html',
  styleUrls: ['./calendario.component.css']
})
export class CalendarioComponent implements OnInit {

  form: FormGroup;
  editar: boolean = false;

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'nombre', 'estado','editar'];

  dataSource = new MatTableDataSource<Calendario>([]);

  mensajeSatisfactorio: string = 'Satisfactorio';

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private fb: FormBuilder,
    private calendarioService: CalendarioService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService
  ) {

  }

  ngOnInit(): void {
    this.buscar();
    this.initForm();
  }

  private initForm(): void {
    this.form = this.fb.group({
      nombre: new FormControl('', Validators.required),
      estado: new FormControl('', Validators.required),
      codigo: new FormControl('')
    })
  }

  clickEnviar() {

    let calendario: Calendario = new Calendario();
    this.spinner.show();

    calendario.nombre = this.form.get('nombre').value;
    calendario.estado = this.form.get('estado').value;
    calendario.codigo = this.form.get('codigo').value;

    if (!this.editar) {

      this.registrar(calendario);

    } else {

      this.actualizar(calendario);

    }

  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    this.spinner.show();
    this.calendarioService.eliminar(this.form.get('codigo').value).subscribe(data => {
      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();
        this.editar = false;
        this.buscar();
    }, err => this.mensajeError(err));

  }

  registrar(calendario: Calendario): void {

    this.calendarioService.crear(calendario).subscribe(data => {

      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscar();

    }, err => this.mensajeError(err));
  }

  actualizar(calendario: Calendario): void {

    this.calendarioService.editar(calendario).subscribe(data => {
      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscar();
    }, err => this.mensajeError(err));

  }

  buscar() {
    this.calendarioService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<Calendario>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: Calendario){
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('nombre').setValue(element.nombre);
    this.form.get('estado').setValue(element.estado);
  }

}

interface Estado {
  value: number;
  viewValue: string;
}
