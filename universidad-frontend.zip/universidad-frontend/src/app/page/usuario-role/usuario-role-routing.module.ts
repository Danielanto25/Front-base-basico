import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { UsuarioRoleComponent } from './usuario-role.component';


const routes: Routes = [
  {
  path: '',
  component: UsuarioRoleComponent
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UsuarioRoleRoutingModule { }
