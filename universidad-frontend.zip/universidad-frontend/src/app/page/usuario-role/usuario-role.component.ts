import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, Validators, FormBuilder, FormGroup } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { NgxSpinnerService } from 'ngx-spinner';
import { UsuarioRoleService } from 'src/app/service/usuario-role.service';
import { MatPaginator } from '@angular/material/paginator';
import { UsuarioRole } from '../../model/usuario-role';
import { Usuario } from 'src/app/model/usuario';
import { Role } from 'src/app/model/role';
import { UsuarioService } from 'src/app/service/usuario.service';
import { RoleService } from 'src/app/service/role.service';

@Component({
  selector: 'app-usuario-role',
  templateUrl: './usuario-role.component.html',
  styleUrls: ['./usuario-role.component.css']
})
export class UsuarioRoleComponent implements OnInit {

  form: FormGroup;
  editar: boolean = false;
  variable: number;
  variable2: number;
  lstRolCodigo: Role[];
  lstUsuCodigo: Usuario[];
  

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'usuario', 'role', 'estado', 'editar'];

  dataSource = new MatTableDataSource<UsuarioRole>([]);

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private fb: FormBuilder,
    private usuarioRoleService: UsuarioRoleService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private usuarioService: UsuarioService,
    private roleService: RoleService
  ) {

  }

  ngOnInit(): void {
    this.buscarPersona();
    this.initForm();
    this.listarRole();
    this.listarUsuario();
  }

  private initForm(): void {
    this.form = this.fb.group({
      usuario: new FormControl('', Validators.required),
      role: new FormControl('', Validators.required),
      codigo: new FormControl(''),
      estado: new FormControl('', Validators.required)
    })
  }

  clickEnviar() {

    let usuarioRole: UsuarioRole = new UsuarioRole();
    let usuario: Usuario = new Usuario();
    let role: Role = new Role();
    this.spinner.show();

    usuario.codigo = this.form.get('usuario').value;
    usuarioRole.user = usuario;
    role.codigo = this.form.get('role').value;
    usuarioRole.role = role;
    usuarioRole.codigo = this.form.get('codigo').value;
    usuarioRole.estado = this.form.get('estado').value;

    if (!this.editar) {

      this.registrar(usuarioRole);

    } else {

      this.actualizar(usuarioRole);

    }

    this.editar = false;

  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    let usuarioRole: UsuarioRole = new UsuarioRole();
    let usuario: Usuario = new Usuario();
    let role: Role = new Role();
    this.spinner.show();

    usuario.codigo = this.form.get('usuario').value;
    usuarioRole.user = usuario;
    role.codigo = this.form.get('role').value;
    usuarioRole.role = role;
    usuarioRole.codigo = this.form.get('codigo').value;
    usuarioRole.estado = this.form.get('estado').value;

    this.usuarioRoleService.eliminar(usuarioRole).subscribe(data => {
      this.spinner.hide();
        this.toastr.success('satisfactorio');
        this.form.reset();
        this.editar = false;
        this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  registrar(usuarioRole: UsuarioRole): void {

    this.usuarioRoleService.crear(usuarioRole).subscribe(data => {

      this.spinner.hide();
      this.form.reset();

  this.toastr.success('Satisfactorio');
        this.buscarPersona();

    }, err => this.mensajeError(err));
  }

  actualizar(usuarioRole: UsuarioRole): void {

    this.usuarioRoleService.editar(usuarioRole).subscribe(data => {
      this.spinner.hide();

      this.spinner.hide();
      this.form.reset();

  this.toastr.success('Satisfactorio');
        this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  buscarPersona() {
    this.usuarioRoleService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<UsuarioRole>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: UsuarioRole){
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('usuario').setValue(element.user.codigo);
    this.form.get('role').setValue(element.role.codigo);
    this.form.get('estado').setValue(element.estado);
  }

  listarUsuario():void{

    this.usuarioService.buscarTodo().subscribe(data => {
      this.lstUsuCodigo = data;
      console.log(data);
    })

  }

  listarRole():void{

    this.roleService.buscarTodo().subscribe(data => {
      this.lstRolCodigo = data;
    })

  }

}


interface Estado {
  value: number;
  viewValue: string;
}