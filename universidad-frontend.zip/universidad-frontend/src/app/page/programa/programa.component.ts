import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Programa } from 'src/app/model/programa';
import { ProgramaService } from 'src/app/service/programa.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-programa',
  templateUrl: './programa.component.html',
  styleUrls: ['./programa.component.css']
})
export class ProgramaComponent implements OnInit {

  form: FormGroup;

  editar: boolean = false;

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'nombre', 'estado', 'editar'];

  dataSource = new MatTableDataSource<Programa>([]);

  mensajeSatisfactorio: string ='Satisfactorio';

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;


  constructor(
    private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private programaService: ProgramaService
  ) { }



  private initForm(): void {
    this.form = this.fb.group({
      nombre: new FormControl('', Validators.required),
      codigo: new FormControl(''),
      estado: new FormControl('', Validators.required),
    })
  }

  ngOnInit(): void {
    this.initForm();
    this.buscarPrograma();
  }

  buscarPrograma() {
    this.programaService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<Programa>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  clickEnviar() {
    let programa: Programa = new Programa();
    this.spinner.show();
    programa.nombre = this.form.get('nombre').value;
    programa.estado = this.form.get('estado').value;
    programa.codigo = this.form.get('codigo').value;

    if (!this.editar) {

      this.registrar(programa);

    } else {

      this.actualizar(programa);

    }
  }

  registrar(programa: Programa): void {

    this.programaService.crear(programa).subscribe(data => {

      this.spinner.hide();
        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscarPrograma();


    }, err => this.mensajeError(err));
  }

  actualizar(programa: Programa): void {

    this.programaService.editar(programa).subscribe(data => {
      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscarPrograma();
    }, err => this.mensajeError(err));

  }
  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: Programa){
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('nombre').setValue(element.nombre);
    this.form.get('estado').setValue(element.estado);
  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }
}
interface Estado {
  value: number;
  viewValue: string;
}