import { Component, OnInit, Input } from '@angular/core';
import { EstudianteCurso } from 'src/app/model/estudiante-curso';
import { EstudianteCursoService } from 'src/app/service/estudiante-curso.service';

@Component({
  selector: 'app-tabla',
  templateUrl: './tabla.component.html',
  styleUrls: ['./tabla.component.css']
})
export class TablaComponent implements OnInit {

  
  estudianteCurso:EstudianteCurso[];



  constructor(
    private estudianteCursoService:EstudianteCursoService,
  ) { }

  ngOnInit(): void {
   
  }
  
  @Input('estudiante')
  set estudiante(estudiante:number){
    if(estudiante==null){
      return
    }
    console.log("Hola");
    this.estudianteCursoService.listar(estudiante).subscribe(data=>{
      this.estudianteCurso=data;
    });
  }

}
