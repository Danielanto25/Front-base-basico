import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { Estudiante } from '../../model/estudiante';
import { MatPaginator } from '@angular/material/paginator';
import { FormBuilder, FormControl, Validators, FormGroup } from '@angular/forms';
import { EstudianteService } from 'src/app/service/estudiante.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Persona } from 'src/app/model/persona';
import { Programa } from 'src/app/model/programa';
import { PersonaService } from 'src/app/service/persona.service';
import { ProgramaService } from 'src/app/service/programa.service';
import { FocusMonitor } from '@angular/cdk/a11y';

@Component({
  selector: 'app-estudiante',
  templateUrl: './estudiante.component.html',
  styleUrls: ['./estudiante.component.css']
})
export class EstudianteComponent implements OnInit {

  form: FormGroup;
  editar: boolean = false;
  lstProCodigo: Programa[];
  lstPerCodigo: Persona[];
  variable2: number;
  variable: number;
  lstPerCodigoTabla: number;
  lstProCodigoTabla: number;
  mensajeSatisfactorio: string = 'Satisfactorio';
  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  estudiante:number;

  displayedColumns: string[] = ['codigo', 'programa', 'persona','estado', 'editar'];

  dataSource = new MatTableDataSource<Estudiante>([]);

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private fb: FormBuilder,
    private estudianteService: EstudianteService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private personaService: PersonaService,
    private programaService: ProgramaService
  ) {

  }


  ngOnInit(): void {
    this.initForm();
    this.buscar();
    this.listarPersona();
    this.listarPrograma();

  }

  private initForm(): void {
    this.form = this.fb.group({
      programa: new FormControl('', Validators.required),
      persona: new FormControl('', Validators.required),
      estado: new FormControl('', Validators.required),
      codigo: new FormControl('')
    })
  }

  clickEnviar() {

    let estudiante: Estudiante = new Estudiante();
    let programa: Programa = new Programa();
    let persona: Persona = new Persona();
    this.spinner.show();
    estudiante.codigo = this.form.get('codigo').value;
    persona.codigo = this.form.get('persona').value;
    programa.codigo = this.form.get('programa').value;
    estudiante.persona = persona;
    estudiante.programa = programa;
    estudiante.estado = this.form.get('estado').value;

    console.log(estudiante);

    if (!this.editar) {

      this.registrar(estudiante);

    } else {

      this.actualizar(estudiante);

    }

  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    let estudiante: Estudiante = new Estudiante();
    let programa: Programa = new Programa();
    let persona: Persona = new Persona();
    this.spinner.show();
    estudiante.codigo = this.form.get('codigo').value;
    persona.codigo = this.form.get('persona').value;
    programa.codigo = this.form.get('programa').value;
    estudiante.persona = persona;
    estudiante.programa = programa;
    estudiante.estado = this.form.get('estado').value;

    this.spinner.show();
    this.estudianteService.eliminar(estudiante).subscribe(data => {
      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();
        this.editar = false;
        this.buscar();
    }, err => this.mensajeError(err));

  }

  registrar(estudiante: Estudiante): void {

    this.estudianteService.crear(estudiante).subscribe(data => {

      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscar();

    }, err => this.mensajeError(err));
  }

  actualizar(estudiante: Estudiante): void {

    this.estudianteService.editar(estudiante).subscribe(data => {
      this.spinner.hide();

        this.toastr.success(this.mensajeSatisfactorio);
        this.form.reset();

        this.buscar();

    }, err => this.mensajeError(err));

  }

  buscar() {
    this.estudianteService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<Estudiante>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  listarPersona() {
    this.personaService.buscarTodo().subscribe(data => {
      this.lstPerCodigo = data;
    })
  }
  listarPrograma() {
    this.programaService.buscarTodo().subscribe(data => {
      this.lstProCodigo = data;
    })
  }
  onEditarClick(element: Estudiante) {
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('persona').setValue(element.persona.codigo);
    this.form.get('programa').setValue(element.programa.codigo);
    this.form.get('estado').setValue(element.estado);
    this.estudiante=element.codigo;

  }
}

interface Estado {
  value: number;
  viewValue: string;
}