import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import {RutaService}from '../../service/ruta.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  usuario: string = localStorage.getItem('usuario');

  titulo: string;

  constructor(
    private router:Router,
    private rutaService:RutaService
  ) { }

  ngOnInit(): void {
  }
  pagina(ruta:string):void{
    this.rutaService.titulo.emit(ruta.toUpperCase());
    this.router.navigateByUrl(ruta);
  }
   
}
