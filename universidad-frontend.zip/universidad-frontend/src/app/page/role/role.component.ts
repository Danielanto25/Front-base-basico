import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
import { RoleService } from 'src/app/service/role.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Role } from 'src/app/model/role';

@Component({
  selector: 'app-role',
  templateUrl: './role.component.html',
  styleUrls: ['./role.component.css']
})
export class RoleComponent implements OnInit {

  form: FormGroup;
  editar: boolean = false;

  estado: Estado[] = [
    {value: 0, viewValue: 'Inactivo'},
    {value: 1, viewValue: 'Activo'}
  ];

  displayedColumns: string[] = ['codigo', 'nombre', 'estado', 'editar'];

  dataSource = new MatTableDataSource<Role>([]);

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  constructor(
    private fb: FormBuilder,
    private roleService: RoleService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService
  ) {

  }

  ngOnInit(): void {
    this.buscarPersona();
    this.initForm();
  }

  private initForm(): void {
    this.form = this.fb.group({
      nombre: new FormControl('', Validators.required),
      codigo: new FormControl(''),
      estado: new FormControl('', Validators.required)
    })
  }

  clickEnviar() {

    let role: Role = new Role();
    this.spinner.show();

    role.nombre = this.form.get('nombre').value;
    role.codigo = this.form.get('codigo').value;
    role.estado = this.form.get('estado').value;

    if (!this.editar) {

      this.registrar(role);

    } else {

      this.actualizar(role);

    }

  }

  onCancelar() {

    this.form.reset();
    this.editar = false;

  }

  onEliminar() {

    let role: Role = new Role();
    this.spinner.show();

    role.nombre = this.form.get('nombre').value;
    role.codigo = this.form.get('codigo').value;
    role.estado = this.form.get('estado').value;

    this.spinner.show();
    this.roleService.eliminar(role).subscribe(data => {
      this.spinner.hide();
        this.toastr.success('satisfactorio');
        this.form.reset();
        this.editar = false;
        this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  registrar(role: Role): void {

    this.roleService.crear(role).subscribe(data => {

      this.spinner.hide();
      this.form.reset();

  this.toastr.success('Satisfactorio');
        this.buscarPersona();

    }, err => this.mensajeError(err));
  }

  actualizar(role: Role): void {

    this.roleService.editar(role).subscribe(data => {
      this.spinner.hide();

      this.spinner.hide();
      this.form.reset();

  this.toastr.success('Satisfactorio');
        this.buscarPersona();
    }, err => this.mensajeError(err));

  }

  buscarPersona() {
    this.roleService.buscarTodo().subscribe(data => {
      this.dataSource = new MatTableDataSource<Role>(data);
      this.paginator.firstPage();
      this.dataSource.paginator = this.paginator;
    });
  }

  private mensajeError(err: any) {
    this.spinner.hide();
    console.log(err);
    this.toastr.error('Ha ocurrido un problema ');
  }

  onEditarClick(element: Role){
    this.editar = true;
    this.form.get('codigo').setValue(element.codigo);
    this.form.get('nombre').setValue(element.nombre);
    this.form.get('estado').setValue(element.estado);
  }

}

interface Estado {
  value: number;
  viewValue: string;
}