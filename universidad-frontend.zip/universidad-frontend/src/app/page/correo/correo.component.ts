import { Component, OnInit } from '@angular/core';
import { CorreoService } from '../../service/correo.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Correo } from 'src/app/model/correo';
import { SubirArchivoService } from '../../service/subir-archivo.service';

@Component({
  selector: 'app-correo',
  templateUrl: './correo.component.html',
  styleUrls: ['./correo.component.css']
})
export class CorreoComponent implements OnInit {

  file: FileList;
  file2: FileList;

  form: FormGroup;
  constructor(
    private correoService: CorreoService,
    private fb: FormBuilder,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private archivoService: SubirArchivoService,
  ) { }

  ngOnInit(): void {
    this.initForm();
    this.toastr.success("hola amiguito");
  }

  initForm(): void {
    this.form = this.fb.group({
      cuerpo: new FormControl('', Validators.required),
      asunto: new FormControl('', Validators.required),
      archivo: new FormControl(''),
      imagen: new FormControl(''),
    })
  }

  enviarCorreo(): void {

    if ((this.form.get('imagen').value != "")&&(this.form.get('archivo').value != "")  ) {

      this.correoCompleto();

    } else {
      if ((this.form.get('archivo').value != "") && (this.form.get('imagen').value == "")) {

        this.correoSinImagen();
      } else {
        if ((this.form.get('imagen').value != "") && (this.form.get('archivo').value)=="") {

          this.correoSinArchivo();
        } else {

          this.correoSoloTexto();
        }

      }

    }


  }


  correoSinImagen(): void {

    let archivo: File = this.file.item(0);

    let correo: Correo = new Correo();

    correo.asunto = this.form.get('asunto').value;
    correo.descripcion = this.form.get('cuerpo').value;

    this.correoService.enviarCorreoSinImagen(archivo, correo).subscribe(data => {
      this.toastr.success("Correo Enviado");
    })

  }
  correoCompleto(): void {

    let archivo: File = this.file.item(0);

    let correo: Correo = new Correo();

    let imagen: File = this.file2.item(0);

    correo.asunto = this.form.get('asunto').value;
    correo.descripcion = this.form.get('cuerpo').value;

    this.correoService.enviarCorreo(archivo, correo, imagen).subscribe(data => {
      this.toastr.success("Correo Enviado");
    })
  }

  correoSinArchivo(): void {

    let correo: Correo = new Correo();

    let imagen: File = this.file2.item(0);

    correo.asunto = this.form.get('asunto').value;
    correo.descripcion = this.form.get('cuerpo').value;

    this.correoService.enviarCorreoSinArchivo(imagen, correo).subscribe(data => {
      this.toastr.success("Correo Enviado");
    })
  }
  correoSoloTexto(): void {

    let correo: Correo = new Correo();

    correo.asunto = this.form.get('asunto').value;
    correo.descripcion = this.form.get('cuerpo').value;

    this.correoService.enviarCorreoSoloTexto(correo).subscribe(data => {
      this.toastr.success("Correo Enviado");
    })
  }


  change(file: FileList): void {
    this.file = file
    this.toastr.success("Archivo Subido");
  }
  change2(file: FileList): void {
    this.file2 = file;
    this.toastr.success("imagen Subido");
  }

}
