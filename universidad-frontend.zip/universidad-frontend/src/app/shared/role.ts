export const role = {

    estudiante:'ROLE_ESTUDIANTE',
    administrador:'ROLE_ADMIN',
    profesor: 'ROLE_PROFESOR',
    authenticated: 'AUTHENTICATED'


}
