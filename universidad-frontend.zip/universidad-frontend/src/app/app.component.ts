import { Component, OnInit } from '@angular/core';
import { LoginService } from './service/login.service';
import { environment } from '../environments/environment';
import { Router } from '@angular/router';
import { RutaService } from './service/ruta.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  ocultarNav: boolean = true;
  titulo: string='LOGIN';
  constructor(
    private loginService: LoginService,
    private router:Router,
    private ruta:RutaService
  ) {
  }
  ngOnInit(): void {
   this.ruta.titulo.subscribe((data:string)=>{
     this.titulo=data;
   })
  }

  
  
  onLoginClick(): void {

    this.loginService.login('admin', '123456').subscribe(res => {

      sessionStorage.setItem(environment.tokenName, res.access_token);
      // redireccionar a pagina de inciio
      console.log(res);

    }, err => {

      console.log(err);

      if(err.status == 500) {

        // error en el servidor
        console.log('error');

      } else {

        // credenciales incorrectas
        console.log('credenciales incorrectas');
      }
    });
  }

  pagina(ruta:string):void{
    this.titulo = ruta.toUpperCase();
    this.router.navigateByUrl(ruta);
  }
  cerrarSesion():void{
    this.titulo='LOGIN';
    sessionStorage.clear();
    localStorage.clear();
    this.router.navigateByUrl('login');
  }
}

