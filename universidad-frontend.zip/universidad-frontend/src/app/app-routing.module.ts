import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SinPermisoComponent } from './page/sin-permiso/sin-permiso.component';
import { LoginComponent } from './page/login/login.component';
import {AdminGuardService} from './guard/admin-guard.service';
import {EstudianteAdminGuardService} from './guard/estudiante-admin-guard.service';

const routes: Routes = [
  {
    path: 'persona',
    loadChildren:()=> import('./page/persona/persona.module').then(m=>m.PersonaModule),
    canActivate:[AdminGuardService]
  },
  {
    path: 'estudiante',
    loadChildren:()=> import('./page/estudiante/estudiante.module').then(m=>m.EstudianteModule),
    canActivate:[AdminGuardService]
  },
  {
    path: 'curso',
    loadChildren:()=> import('./page/curso/curso.module').then(m=>m.CursoModule),
    canActivate:[AdminGuardService]
  },
  {
    path: 'estudiante-curso',
    loadChildren:()=> import('./page/estudiante-curso/estudiante-curso.module').then(m=>m.EstudianteCursoModule),
    canActivate:[EstudianteAdminGuardService],
  },
  {
    path: 'estudiante-calendario',
    loadChildren:()=> import('./page/estudiante-calendario/estudiante-calendario.module').then(m=>m.EstudianteCalendarioModule),
    canActivate:[EstudianteAdminGuardService],

  },
  {
    path: 'calendario',
    loadChildren:()=> import('./page/calendario/calendario.module').then(m=>m.CalendarioModule),
    canActivate:[EstudianteAdminGuardService],
  },
  {
    path: 'programa',
    loadChildren:()=> import('./page/programa/programa.module').then(m=>m.ProgramaModule),
    canActivate:[AdminGuardService]
  },
  {
    path: 'role',
    loadChildren:()=> import('./page/role/role.module').then(m=>m.RoleModule),
    canActivate:[AdminGuardService]
  },
  {
    path: 'usuario',
    loadChildren:()=> import('./page/usuario/usuario.module').then(m=>m.UsuarioModule),
    canActivate:[AdminGuardService]
  },
  {
    path: 'usuario-role',
    loadChildren:()=> import('./page/usuario-role/usuario-role.module').then(m=>m.UsuarioRoleModule),
    canActivate:[AdminGuardService]
  },
  {
    path: 'home',
    loadChildren:()=> import('./page/home/home.module').then(m=>m.HomeModule),
    canActivate:[AdminGuardService]
  },
  {
    path:'sin-permiso',
    component:SinPermisoComponent
  },
  {
    path:'login',
    component:LoginComponent
  },
  {
    path:'padre',
    loadChildren:()=> import('./page/compoente-padre/compoente-padre.module').then(m=>m.CompoentePadreModule)
  },
  {
    path:'correo',
    loadChildren:()=> import('./page/correo/correo.module').then(m=>m.CorreoModule),
    canActivate:[AdminGuardService]
  },
  {
    path: '', 
    component: LoginComponent
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
