export const environment = {
  production: false,
  tokenName: 'token',
  host: 'http://192.168.0.157:8181',
  //host: 'http://localhost:8181',
  tokenClientId: 'clienteid',
  tokenClientSecret: 'secret123',
  apiUrl: 'http://192.168.0.157:8181/api'
  //apiUrl: 'http://localhost:8181/api'
};
